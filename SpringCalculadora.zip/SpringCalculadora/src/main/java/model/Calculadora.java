package model;

import java.util.List;


public class Calculadora {
	
	 public float sumaNros(List<Float> numeros) {
	        float retorno = 0;
	        for (Float n : numeros) {
	            retorno = (n + retorno);
	        }
	        return retorno;
	    }
	 
	 public float multiplicaNros(List<Float> numeros) {
	        float retorno = numeros.size() > 1 ? 1 : 0;
	        for (Float n : numeros) {
	            retorno = (n * retorno);
	        }
	        return retorno;

	    }
	 
	 public float restaNros(Float primerNro,Float segundoNro) {
	      if (primerNro == null && segundoNro == null) {
	            return 0;
	        } else {
	          return primerNro-segundoNro;
	        }
	    }

	 public float divideNro( Float primerNro,  Float segundoNro) {
	      if (primerNro == null && segundoNro == null) {
	            return 0;
	        } else {
	          return primerNro /segundoNro;
	        }
	    }

	

}
