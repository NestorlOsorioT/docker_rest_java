package controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import services.CalculadoraService;

@RestController
public class CalculadoraController {

	@Autowired
	CalculadoraService cal;
	
	@GetMapping("/sumar")
	public Float sumarNumeros(@RequestParam("numeros") List<Float> numeros) {
		return cal.sumarNumeros(numeros);
	}
	
	@GetMapping("/multiplicar")
	public Float multiplicarNumeros(@RequestParam("numeros")  List<Float> numeros) {
		return cal.multiplicarNumeros(numeros);
	}

	 @GetMapping("/restar")
	public Float restarNumeros(@RequestParam("primerNro") Float primerNro, @RequestParam("segundoNro") Float segundoNro) {
		return cal.restarNumeros(primerNro, segundoNro);
	}
	 @GetMapping("/dividir")
	public Float dividirNumeros(@RequestParam("primerNro") Float primerNro, @RequestParam("segundoNro") Float segundoNro) {
		return cal.dividirNumeros(primerNro, segundoNro);
	}
	
	
}
