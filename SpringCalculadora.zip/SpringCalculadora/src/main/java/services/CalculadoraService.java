package services;


import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;


import model.Calculadora;

@Service
@Component
public class CalculadoraService  {

	private Calculadora calculadora=new Calculadora();
	
	public Float sumarNumeros(List<Float> numeros) {
		return calculadora.sumaNros(numeros);
	}
	public Float multiplicarNumeros(List<Float> numeros) {
		return calculadora.multiplicaNros(numeros);
	}
	
	public Float restarNumeros(Float primerNro, Float segundoNro) {
		return calculadora.restaNros(primerNro, segundoNro);
	}
	public Float dividirNumeros(Float primerNro, Float segundoNro) {
		return calculadora.divideNro(primerNro, segundoNro);
	}

	
}
